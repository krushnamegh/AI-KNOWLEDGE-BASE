# AI Knowledge Base With Cloud Storage

A full-stack application demonstrating Cloud Computing and AI concepts. Users can upload documents (PDF, DOCX, TXT) which are stored in the cloud (AWS S3), processed, and vectorized into a local ChromaDB instance. The application then uses OpenAI's GPT models via RAG (Retrieval-Augmented Generation) to answer questions based on the uploaded knowledge base.

## Architecture

```mermaid
graph TD;
    User-->|Uploads Docs|Frontend[React Frontend];
    User-->|Asks Question|Frontend;
    
    Frontend-->|REST API|Backend[FastAPI Backend];
    
    Backend-->|Stores File|S3[AWS S3 Cloud Storage];
    Backend-->|Saves Metadata|SQLite[(SQLite DB)];
    
    Backend-->|Extracts Text & Chunks|Processing[Document Processor];
    Processing-->|Embeddings|VectorDB[(ChromaDB Vector Store)];
    
    Backend-->|Similarity Search|VectorDB;
    VectorDB-->|Context Chunks|Backend;
    
    Backend-->|Context + Question|LLM[OpenAI API];
    LLM-->|Generated Answer|Backend;
```

## Technologies Used

* **Frontend**: React, TypeScript, Vite, Tailwind CSS, Lucide Icons, Axios, React Router.
* **Backend**: Python 3.10+, FastAPI, SQLAlchemy, aiosqlite, pypdf, python-docx.
* **Storage**: AWS S3 (with local fallback if credentials aren't provided).
* **Vector DB**: ChromaDB.
* **AI/LLM**: OpenAI API (Configurable embedding and generation models).
* **Database**: SQLite (for document metadata and tracking).

## Setup & Installation

### 1. Backend

Navigate to the backend directory:
```bash
cd backend
```

Create a virtual environment and install dependencies:
```bash
python -m venv venv
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

pip install -r requirements.txt
```

Set up environment variables:
```bash
cp .env.example .env
```
Edit `.env` and configure your API keys and AWS credentials. 

Run the backend:
```bash
uvicorn main:app --reload
```
The API will run on http://localhost:8000 (Swagger UI at http://localhost:8000/docs).

### 2. Frontend

Navigate to the frontend directory:
```bash
cd frontend
```

Install dependencies:
```bash
npm install
```

Start the development server:
```bash
npm run dev
```
The frontend will run on http://localhost:5173.

## Configuration & Cloud Setup

### AWS S3 Configuration
1. Log into your AWS Console.
2. Go to IAM and create a new user with programmatic access.
3. Attach the `AmazonS3FullAccess` policy (or a more restricted policy for a specific bucket).
4. Save the Access Key ID and Secret Access Key.
5. Go to S3 and create a new bucket in your preferred region. Ensure CORS is configured if you ever plan to do direct frontend uploads (though this architecture uses backend-mediated uploads for simplicity).
6. Put the credentials, region, and bucket name into the `.env` file.

*Note: If AWS credentials are left blank in `.env`, the system will automatically fall back to local storage in the `backend/uploads/` directory, allowing you to develop and test without a cloud setup.*

### OpenAI API Configuration
1. Go to platform.openai.com.
2. Generate an API key.
3. Add it to the `OPENAI_API_KEY` variable in `.env`.
4. (Optional) Adjust the `LLM_MODEL` and `EMBEDDING_MODEL` if you want to use different models (e.g. gpt-4o, text-embedding-3-large).

## How the RAG Pipeline Works

1. **Ingestion**: When a file is uploaded, the FastAPI backend saves it to AWS S3. It then runs a background task to extract plain text (using `pypdf` or `python-docx`), cleans the text, and splits it into overlapping chunks.
2. **Embedding**: The chunks are sent to the embedding model (default `text-embedding-3-small`) to generate vector representations, which are stored in ChromaDB along with metadata (document ID, filename).
3. **Retrieval**: When a user asks a question, the question is embedded using the same model. ChromaDB performs a cosine similarity search to find the top $K$ most relevant text chunks from all uploaded documents.
4. **Generation**: The retrieved chunks are assembled into a context prompt. The system prompt instructs the LLM (default `gpt-3.5-turbo`) to answer the question strictly based on the provided context and to admit if it doesn't know. The response is sent back to the frontend along with the source citations.

## Example Questions to Test

Upload a syllabus or a research paper, then try:
- "What is the main topic of the uploaded document?"
- "What are the key dates mentioned?"
- "Summarize the conclusion in three bullet points."
- "What is the meaning of life?" (The AI should correctly state it cannot find this in the documents).
