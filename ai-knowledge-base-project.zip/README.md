# AI Knowledge Base

A full-stack RAG (Retrieval-Augmented Generation) application that allows you to upload documents and chat with an AI assistant that answers questions based strictly on your document contents.

## 🚀 Features

* **Document Uploads**: Upload documents (txt, pdf, docx, etc.) to the system.
* **Intelligent Document Processing**: Automatically extracts text, chunks it, and indexes it using embeddings.
* **Retrieval-Augmented Generation (RAG)**: Chat with the AI about your documents. The AI provides answers strictly based on the provided context.
* **Source Citations**: AI responses include citations and excerpts from the original source documents.
* **Google Gemini Integration**: Uses Google's Gemini models for both embeddings (`models/gemini-embedding-001`) and chat (`models/gemini-3.5-flash`).

## 🛠️ Tech Stack

* **Frontend**: React, Vite, Tailwind CSS
* **Backend**: FastAPI, Python
* **Vector Database**: ChromaDB (Local embedded mode)
* **LLM & Embeddings**: Google Generative AI (Gemini)

## ⚙️ Local Setup

### 1. Backend Setup

1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Create and activate a Python virtual environment:
   ```bash
   python -m venv venv
   # Windows:
   .\venv\Scripts\activate
   # Mac/Linux:
   source venv/bin/activate
   ```
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Configure environment variables:
   Create a `.env` file in the `backend/` directory and add your Google Gemini API key:
   ```env
   GEMINI_API_KEY="your-gemini-api-key"
   ```
5. Start the backend server:
   ```bash
   uvicorn main:app --host 127.0.0.1 --port 8000
   ```

### 2. Frontend Setup

1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open your browser and navigate to `http://localhost:5173`.

## 📁 Project Structure

* `/backend` - FastAPI server, RAG logic, ChromaDB integration, and API endpoints.
* `/frontend` - React application, dashboard, upload interface, and chat UI.
