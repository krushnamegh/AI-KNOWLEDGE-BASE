"""
Chat API route — RAG question answering.
"""
import logging

from fastapi import APIRouter, HTTPException

from app.schemas import ChatRequest, ChatResponse
from app.services.ai_service import ai_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/chat", tags=["chat"])


@router.post("", response_model=ChatResponse)
async def chat(request: ChatRequest):
    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be empty.")

    if not ai_service.is_configured:
        raise HTTPException(
            status_code=503,
            detail="LLM API key not configured. Set GEMINI_API_KEY in your .env file.",
        )

    import asyncio

    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(
        None,
        lambda: ai_service.answer_question(request.question, request.top_k),
    )
    return result
