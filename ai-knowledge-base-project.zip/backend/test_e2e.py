import requests
import time

BASE_URL = "http://127.0.0.1:8000/api"

print("1. Testing GET /api/health")
res = requests.get(f"{BASE_URL}/health")
print(res.status_code, res.json())
assert res.status_code == 200

print("\n2. Creating dummy file test_upload.txt")
with open("test_upload.txt", "w") as f:
    f.write("This is a test document containing the secret code: 42-BETA. It is used for verifying the end-to-end pipeline.")

print("\n3. Testing POST /api/documents/upload")
with open("test_upload.txt", "rb") as f:
    res = requests.post(f"{BASE_URL}/documents/upload", files={"file": ("test_upload.txt", f, "text/plain")})
print(res.status_code, res.json())
assert res.status_code == 200
doc_id = res.json()["id"]

print("\n4. Waiting for processing...")
time.sleep(5)
res = requests.get(f"{BASE_URL}/documents/{doc_id}")
status = res.json()["status"]
print("Status:", status)
while status == "processing":
    time.sleep(2)
    res = requests.get(f"{BASE_URL}/documents/{doc_id}")
    status = res.json()["status"]
    print("Status:", status)

print("\n5. Checking ChromaDB extraction via chat")
chat_data = {"question": "What is the secret code?"}
res = requests.post(f"{BASE_URL}/chat", json=chat_data)
print(res.status_code, res.json())
assert res.status_code == 200

print("\nAll tests finished!")
