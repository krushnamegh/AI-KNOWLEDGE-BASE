import time
import requests
import json
import sys

BASE_URL = "http://localhost:8000/api"
TEST_FILE = "test_doc.txt"

def wait_for_server():
    print("Waiting for server to start...")
    for _ in range(30):
        try:
            res = requests.get(f"{BASE_URL}/health")
            if res.status_code == 200:
                print("Server is up!")
                return
        except requests.exceptions.ConnectionError:
            pass
        time.sleep(2)
    print("Server failed to start")
    sys.exit(1)

def run_tests():
    print("\n1. Testing /api/health")
    res = requests.get(f"{BASE_URL}/health")
    print(f"Status: {res.status_code}\nResponse: {res.json()}")

    print("\n2. Testing POST /api/documents/upload")
    with open(TEST_FILE, "rb") as f:
        files = {"file": ("test_doc.txt", f, "text/plain")}
        res = requests.post(f"{BASE_URL}/documents/upload", files=files)
    
    if res.status_code != 200:
        print(f"Upload failed: {res.text}")
        return
    
    doc = res.json()
    doc_id = doc["id"]
    print(f"Status: {res.status_code}\nUploaded Document ID: {doc_id}")

    print("\nWaiting for processing to complete...")
    time.sleep(3)

    print("\n3. Testing GET /api/documents")
    res = requests.get(f"{BASE_URL}/documents")
    print(f"Status: {res.status_code}\nResponse: {json.dumps(res.json(), indent=2)}")

    print(f"\n4. Testing GET /api/documents/{doc_id}")
    res = requests.get(f"{BASE_URL}/documents/{doc_id}")
    print(f"Status: {res.status_code}\nResponse: {json.dumps(res.json(), indent=2)}")

    print("\n5. Testing POST /api/chat")
    # This might fail with 503 if no API key is provided, which is the expected behavior.
    res = requests.post(f"{BASE_URL}/chat", json={"question": "What are vectors?"})
    print(f"Status: {res.status_code}\nResponse: {res.text}")

    print(f"\n6. Testing DELETE /api/documents/{doc_id}")
    res = requests.delete(f"{BASE_URL}/documents/{doc_id}")
    print(f"Status: {res.status_code}\nResponse: {res.text}")

if __name__ == "__main__":
    wait_for_server()
    run_tests()
