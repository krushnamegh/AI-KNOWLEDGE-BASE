import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, FileText, Loader2, Sparkles, BrainCircuit, XCircle } from 'lucide-react';
import { api } from '../api/client';
import type { ChatResponse, ChatSource } from '../api/client';
import { cn } from '../lib/utils';

type Message = {
  role: 'user' | 'assistant';
  content: string;
  sources?: ChatSource[];
  isError?: boolean;
};

const SUGGESTIONS = [
  "What are the main topics in my documents?",
  "Summarize the uploaded document.",
  "What are the key findings?",
  "Extract the most important statistics."
];

export function Chat() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = async (e?: React.FormEvent, suggestionText?: string) => {
    e?.preventDefault();
    const text = suggestionText || input;
    if (!text.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: text };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const res = await api.chat.ask(text);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: res.answer,
        sources: res.sources
      }]);
    } catch (err: any) {
      console.error('Chat failed', err);
      const errorMsg = err.response?.data?.detail || 'Failed to connect to AI Service. Make sure the backend is running and LLM is configured.';
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: errorMsg,
        isError: true
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)] animate-in fade-in slide-in-from-bottom-4 duration-500 max-w-5xl mx-auto">
      <header className="mb-6 flex items-center gap-4">
        <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center border border-primary/20">
          <BrainCircuit className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-foreground flex items-center gap-2">
            Knowledge Assistant <Sparkles className="w-5 h-5 text-amber-400" />
          </h1>
          <p className="text-sm text-muted-foreground">Ask questions about your uploaded documents.</p>
        </div>
      </header>
      
      <div className="flex-1 bg-card border border-border rounded-3xl overflow-hidden flex flex-col shadow-sm">
        <div className="flex-1 overflow-y-auto p-6 space-y-8 scroll-smooth">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center max-w-2xl mx-auto px-4">
              <div className="w-20 h-20 bg-primary/5 rounded-3xl flex items-center justify-center mb-6 border border-border">
                <Bot className="w-10 h-10 text-primary opacity-50" />
              </div>
              <h2 className="text-2xl font-bold mb-2">How can I help you today?</h2>
              <p className="text-muted-foreground mb-8">
                I can analyze your indexed documents, extract key information, and answer specific questions based on your cloud storage knowledge base.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
                {SUGGESTIONS.map((suggestion, i) => (
                  <button
                    key={i}
                    onClick={() => handleSubmit(undefined, suggestion)}
                    className="p-4 border border-border rounded-2xl text-sm text-left hover:bg-muted/50 hover:border-primary/50 transition-colors font-medium flex items-center gap-3 text-muted-foreground hover:text-foreground"
                  >
                    <MessageSquareText className="w-4 h-4 shrink-0 opacity-50" />
                    {suggestion}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div key={idx} className={cn("flex gap-4", msg.role === 'user' ? 'justify-end' : 'justify-start')}>
                {msg.role === 'assistant' && (
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20 mt-1">
                    <Bot className="w-5 h-5 text-primary" />
                  </div>
                )}
                
                <div className={cn(
                  "max-w-[85%] sm:max-w-[75%]",
                  msg.role === 'user' ? "order-1" : "order-2"
                )}>
                  <div className={cn(
                    "px-6 py-4 rounded-3xl",
                    msg.role === 'user' 
                      ? "bg-primary text-primary-foreground font-medium rounded-br-sm shadow-sm" 
                      : msg.isError 
                        ? "bg-red-500/10 border border-red-500/20 text-red-500 rounded-bl-sm"
                        : "bg-muted/50 border border-border text-foreground rounded-bl-sm prose prose-sm dark:prose-invert max-w-none"
                  )}>
                    {msg.isError && <XCircle className="w-5 h-5 inline-block mr-2 mb-1" />}
                    {msg.content}
                  </div>
                  
                  {msg.sources && msg.sources.length > 0 && (
                    <div className="mt-3 space-y-2">
                      <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5 ml-1">
                        <FileText className="w-3.5 h-3.5" /> Sources
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {msg.sources.map((source, i) => (
                          <div key={i} className="bg-background border border-border rounded-xl p-3 text-xs flex-1 min-w-[200px] max-w-sm hover:border-primary/30 transition-colors shadow-sm">
                            <span className="font-semibold text-primary truncate block mb-1.5">{source.filename}</span>
                            <span className="text-muted-foreground line-clamp-3 leading-relaxed">"...{source.chunk_text}..."</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {msg.role === 'user' && (
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center shrink-0 border border-border mt-1 order-2">
                    <User className="w-5 h-5 text-muted-foreground" />
                  </div>
                )}
              </div>
            ))
          )}
          
          {isLoading && (
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 border border-primary/20">
                <Loader2 className="w-5 h-5 text-primary animate-spin" />
              </div>
              <div className="bg-muted/50 border border-border px-6 py-4 rounded-3xl rounded-bl-sm flex items-center gap-3">
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-sm font-medium text-muted-foreground ml-2">Searching your knowledge base...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-background border-t border-border">
          <form onSubmit={handleSubmit} className="relative flex items-center max-w-4xl mx-auto">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question about your documents..."
              className="w-full bg-muted border border-border text-foreground px-6 py-4 pr-16 rounded-full focus:outline-none focus:ring-2 focus:ring-primary/50 transition-shadow"
              disabled={isLoading}
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="absolute right-2 p-3 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

// Add MessageSquareText icon component since we use it but haven't imported it from lucide-react directly
import { MessageSquareText } from 'lucide-react';
